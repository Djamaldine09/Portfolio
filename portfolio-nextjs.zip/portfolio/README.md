# Portfolio — Alex Moreau

Portfolio full-stack en Next.js 16 (App Router) + TypeScript + Tailwind CSS 4.
Thème : glassmorphism sombre, halos de lumière animés, terminal signature qui tape du code en direct dans le hero.

## Démarrer

npm install
npm run dev

Puis ouvrir http://localhost:3000

## Personnaliser
- Contenu : app/page.tsx assemble les sections. Chaque section est un composant dans components/.
- Nom, titre, bio : components/Hero.tsx et components/About.tsx
- Projets : components/Projects.tsx (tableau PROJECTS)
- Compétences : components/Skills.tsx (tableau GROUPS)
- Liens de contact : components/Contact.tsx (tableau LINKS)
- Couleurs / halos / verre : app/globals.css (variables :root)

## Build de production

npm run build
npm run start
