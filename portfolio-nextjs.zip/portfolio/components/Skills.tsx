const GROUPS = [
  {
    title: "Frontend",
    items: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
  },
  {
    title: "Backend",
    items: ["Node.js", "PostgreSQL", "Redis", "REST & GraphQL"],
  },
  {
    title: "Infrastructure",
    items: ["Docker", "AWS", "CI/CD", "Monitoring"],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="relative py-28 px-6">
      <div className="mx-auto max-w-5xl">
        <p className="font-mono text-sm text-[#5eead4] mb-4">Compétences</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-14">
          Les outils que j&apos;utilise au quotidien.
        </h2>

        <div className="grid sm:grid-cols-3 gap-6">
          {GROUPS.map((g) => (
            <div key={g.title} className="glass rounded-2xl p-7">
              <h3 className="font-mono text-sm text-[#a78bfa] mb-5">
                {g.title}
              </h3>
              <ul className="space-y-3">
                {g.items.map((item) => (
                  <li
                    key={item}
                    className="text-[#c3cad4] flex items-center gap-2.5"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#5eead4] shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
