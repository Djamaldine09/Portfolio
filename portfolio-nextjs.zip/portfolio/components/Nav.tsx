"use client";

const LINKS = [
  { href: "#about", label: "Profil" },
  { href: "#projects", label: "Projets" },
  { href: "#skills", label: "Compétences" },
  { href: "#contact", label: "Contact" },
];

export default function Nav() {
  return (
    <header className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-3xl">
      <nav className="glass rounded-full px-5 py-3 flex items-center justify-between shadow-lg shadow-black/20">
        <a href="#top" className="font-mono text-sm text-[#5eead4] tracking-tight">
          alex.dev
        </a>
        <div className="hidden sm:flex items-center gap-6">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-[#8b95a3] hover:text-[#e8ecf1] transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>
        <a
          href="#contact"
          className="text-sm font-medium px-4 py-1.5 rounded-full bg-gradient-to-r from-[#5eead4] to-[#a78bfa] text-[#05070a] hover:opacity-90 transition-opacity"
        >
          Discutons
        </a>
      </nav>
    </header>
  );
}
