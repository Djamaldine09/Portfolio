const FACTS = [
  { label: "Années d'expérience", value: "6+" },
  { label: "Projets livrés", value: "40+" },
  { label: "Stack de prédilection", value: "TS · Node · SQL" },
];

export default function About() {
  return (
    <section id="about" className="relative py-28 px-6">
      <div className="mx-auto max-w-4xl">
        <p className="font-mono text-sm text-[#5eead4] mb-4">Profil</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-8">
          Je construis des systèmes qui tiennent la route.
        </h2>
        <div className="glass rounded-2xl p-8 sm:p-10">
          <p className="text-lg text-[#c3cad4] leading-relaxed mb-6">
            Depuis six ans, je conçois des produits web pour des équipes qui
            ont besoin de fiabilité autant que de vitesse. J&apos;aime autant
            modéliser une base de données propre que peaufiner une animation
            d&apos;interface — les deux bouts du même métier.
          </p>
          <p className="text-lg text-[#c3cad4] leading-relaxed mb-10">
            Mon approche : comprendre le problème avant d&apos;écrire une
            ligne de code, choisir des outils simples plutôt qu&apos;à la
            mode, et livrer quelque chose que je serais fier de maintenir
            dans deux ans.
          </p>

          <div className="grid grid-cols-3 gap-6 pt-8 border-t border-white/10">
            {FACTS.map((f) => (
              <div key={f.label}>
                <div className="text-2xl sm:text-3xl font-semibold text-gradient mb-1">
                  {f.value}
                </div>
                <div className="text-xs sm:text-sm text-[#8b95a3]">
                  {f.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
