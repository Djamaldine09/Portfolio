import { Mail } from "lucide-react";

function GithubIcon() {
  return (
    <svg viewBox="0 0 24 24" width={18} height={18} fill="currentColor" aria-hidden="true">
      <path d="M12 .5C5.73.5.5 5.73.5 12c0 5.08 3.29 9.39 7.86 10.91.57.11.78-.25.78-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.87-1.36-3.87-1.36-.53-1.34-1.29-1.7-1.29-1.7-1.05-.72.08-.7.08-.7 1.17.08 1.78 1.2 1.78 1.2 1.03 1.77 2.71 1.26 3.37.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.25.45-2.28 1.19-3.08-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11 11 0 0 1 5.79 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.8 1.19 1.83 1.19 3.08 0 4.41-2.69 5.38-5.25 5.67.41.36.78 1.06.78 2.14 0 1.54-.01 2.79-.01 3.17 0 .3.2.67.79.55A10.51 10.51 0 0 0 23.5 12C23.5 5.73 18.27.5 12 .5Z" />
    </svg>
  );
}

function LinkedinIcon() {
  return (
    <svg viewBox="0 0 24 24" width={18} height={18} fill="currentColor" aria-hidden="true">
      <path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.03-1.85-3.03-1.86 0-2.15 1.45-2.15 2.94v5.66H9.34V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.34 7.43a2.07 2.07 0 1 1 0-4.13 2.07 2.07 0 0 1 0 4.13ZM7.12 20.45H3.56V9h3.56v11.45ZM22.22 0H1.77C.8 0 0 .78 0 1.75v20.5C0 23.22.8 24 1.77 24h20.45c.98 0 1.78-.78 1.78-1.75V1.75C24 .78 23.2 0 22.22 0Z" />
    </svg>
  );
}

const LINKS = [
  { label: "GitHub", href: "https://github.com", icon: GithubIcon },
  { label: "LinkedIn", href: "https://linkedin.com", icon: LinkedinIcon },
  { label: "Email", href: "mailto:alex@example.com", icon: Mail },
];

export default function Contact() {
  return (
    <section id="contact" className="relative py-28 px-6">
      <div className="mx-auto max-w-3xl text-center">
        <p className="font-mono text-sm text-[#5eead4] mb-4">Contact</p>
        <h2 className="text-3xl sm:text-5xl font-semibold tracking-tight mb-6">
          Une idée à <span className="text-gradient">construire ensemble</span> ?
        </h2>
        <p className="text-lg text-[#8b95a3] mb-10 max-w-xl mx-auto">
          Je suis ouvert aux missions freelance et aux opportunités
          full-time. Écrivez-moi, je réponds sous 48 heures.
        </p>

        <a
          href="mailto:alex@example.com"
          className="inline-block px-8 py-4 rounded-full bg-gradient-to-r from-[#5eead4] to-[#a78bfa] text-[#05070a] font-medium text-lg hover:opacity-90 transition-opacity mb-12"
        >
          alex@example.com
        </a>

        <div className="flex items-center justify-center gap-4">
          {LINKS.map(({ label, href, icon: Icon }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              className="glass w-11 h-11 rounded-full flex items-center justify-center text-[#c3cad4] hover:text-[#5eead4] hover:bg-white/[0.06] transition-colors"
            >
              <Icon />
            </a>
          ))}
        </div>
      </div>

      <footer className="text-center mt-24 text-sm text-[#4d5560] font-mono">
        © {new Date().getFullYear()} Alex Moreau — conçu et développé à la main.
      </footer>
    </section>
  );
}
