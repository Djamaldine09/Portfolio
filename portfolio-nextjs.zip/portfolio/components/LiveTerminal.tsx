"use client";

import { useEffect, useState } from "react";

type Line = { text: string; type: "comment" | "keyword" | "plain" | "string" | "output" };

const SCRIPT: Line[] = [
  { text: "// pile technique", type: "comment" },
  { text: "const stack = {", type: "plain" },
  { text: '  frontend: ["Next.js", "React", "TypeScript"],', type: "string" },
  { text: '  backend: ["Node.js", "PostgreSQL", "Redis"],', type: "string" },
  { text: '  infra: ["Docker", "AWS", "CI/CD"],', type: "string" },
  { text: "};", type: "plain" },
  { text: "", type: "plain" },
  { text: "function ship(idea) {", type: "keyword" },
  { text: "  const code = design(idea);", type: "plain" },
  { text: "  const tested = review(code);", type: "plain" },
  { text: "  return deploy(tested);", type: "plain" },
  { text: "}", type: "keyword" },
  { text: "", type: "plain" },
  { text: "> ship(\"portfolio\")", type: "output" },
  { text: "✓ déployé en production", type: "output" },
];

const COLORS: Record<Line["type"], string> = {
  comment: "text-[#6b7583]",
  keyword: "text-[#a78bfa]",
  plain: "text-[#e8ecf1]",
  string: "text-[#5eead4]",
  output: "text-[#fbbf6b]",
};

export default function LiveTerminal() {
  const [visibleLines, setVisibleLines] = useState(0);
  const [charsInLine, setCharsInLine] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (visibleLines >= SCRIPT.length) {
      setDone(true);
      return;
    }
    const currentLine = SCRIPT[visibleLines];
    if (charsInLine < currentLine.text.length) {
      const t = setTimeout(() => setCharsInLine((c) => c + 1), 14);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => {
        setVisibleLines((l) => l + 1);
        setCharsInLine(0);
      }, 90);
      return () => clearTimeout(t);
    }
  }, [visibleLines, charsInLine]);

  return (
    <div className="glass-strong rounded-2xl overflow-hidden shadow-2xl shadow-black/40 w-full max-w-lg">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
        <span className="w-3 h-3 rounded-full bg-[#ff5f57]/70" />
        <span className="w-3 h-3 rounded-full bg-[#febc2e]/70" />
        <span className="w-3 h-3 rounded-full bg-[#28c840]/70" />
        <span className="ml-3 text-xs font-mono text-[#6b7583]">alex@dev — zsh</span>
      </div>
      <pre className="p-5 text-[13px] leading-relaxed font-mono min-h-[320px] overflow-hidden">
        {SCRIPT.slice(0, visibleLines).map((line, i) => (
          <div key={i} className={COLORS[line.type]}>
            {line.text || "\u00A0"}
          </div>
        ))}
        {!done && (
          <div className={COLORS[SCRIPT[visibleLines]?.type ?? "plain"]}>
            {SCRIPT[visibleLines]?.text.slice(0, charsInLine)}
            <span className="cursor-blink text-[#5eead4]">▍</span>
          </div>
        )}
        {done && <span className="cursor-blink text-[#5eead4]">▍</span>}
      </pre>
    </div>
  );
}
