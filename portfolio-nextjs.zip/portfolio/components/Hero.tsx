import LiveTerminal from "./LiveTerminal";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-[100svh] flex items-center pt-28 pb-16 px-6"
    >
      <div className="mx-auto max-w-6xl w-full grid lg:grid-cols-[1.1fr_1fr] gap-14 items-center">
        <div>
          <p className="font-mono text-sm text-[#5eead4] mb-5">
            Bonjour, je suis
          </p>
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-semibold leading-[1.02] tracking-tight mb-6">
            Alex Moreau,
            <br />
            <span className="text-gradient">ingénieur full-stack.</span>
          </h1>
          <p className="text-lg text-[#8b95a3] max-w-md mb-9 leading-relaxed">
            Je conçois des applications web de bout en bout — du schéma de
            base de données à l&apos;interface que les gens touchent vraiment.
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="#projects"
              className="px-6 py-3 rounded-full bg-gradient-to-r from-[#5eead4] to-[#a78bfa] text-[#05070a] font-medium hover:opacity-90 transition-opacity"
            >
              Voir mes projets
            </a>
            <a
              href="#contact"
              className="px-6 py-3 rounded-full glass text-[#e8ecf1] font-medium hover:bg-white/[0.06] transition-colors"
            >
              Me contacter
            </a>
          </div>
        </div>

        <div className="flex justify-center lg:justify-end">
          <LiveTerminal />
        </div>
      </div>

      <a
        href="#about"
        aria-label="Défiler vers la section profil"
        className="hidden sm:flex absolute bottom-8 left-1/2 -translate-x-1/2 flex-col items-center gap-2 text-[#4d5560] hover:text-[#8b95a3] transition-colors"
      >
        <span className="text-xs font-mono">scroll</span>
        <ArrowDown size={16} className="animate-bounce" />
      </a>
    </section>
  );
}
