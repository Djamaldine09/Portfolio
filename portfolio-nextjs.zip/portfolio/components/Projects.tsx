import { ArrowUpRight } from "lucide-react";

const PROJECTS = [
  {
    title: "Orbit — Suivi de flotte en temps réel",
    description:
      "Plateforme de suivi de véhicules avec cartes en direct, alertes automatisées et tableau de bord opérationnel pour une équipe de 200 chauffeurs.",
    stack: ["Next.js", "PostgreSQL", "WebSockets", "Mapbox"],
    href: "#",
  },
  {
    title: "Ledger — Facturation pour indépendants",
    description:
      "Application de facturation et de suivi de trésorerie, du devis au paiement, avec génération de PDF et rapprochement bancaire automatique.",
    stack: ["React", "Node.js", "Stripe", "Redis"],
    href: "#",
  },
  {
    title: "Signal — API d'analytics événementielle",
    description:
      "Service d'ingestion d'événements à haut débit, avec agrégation en quasi temps réel et export vers les outils BI de l'équipe produit.",
    stack: ["Go", "Kafka", "ClickHouse", "Docker"],
    href: "#",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="relative py-28 px-6">
      <div className="mx-auto max-w-5xl">
        <p className="font-mono text-sm text-[#5eead4] mb-4">Projets</p>
        <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight mb-14">
          Ce que j&apos;ai construit récemment.
        </h2>

        <div className="grid gap-6">
          {PROJECTS.map((p) => (
            <a
              key={p.title}
              href={p.href}
              className="group glass rounded-2xl p-7 sm:p-9 flex flex-col sm:flex-row sm:items-center gap-6 hover:bg-white/[0.06] hover:border-white/20 transition-all"
            >
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <h3 className="text-xl sm:text-2xl font-medium">
                    {p.title}
                  </h3>
                  <ArrowUpRight
                    size={20}
                    className="text-[#5eead4] opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all shrink-0"
                  />
                </div>
                <p className="text-[#8b95a3] leading-relaxed mb-4 max-w-xl">
                  {p.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {p.stack.map((s) => (
                    <span
                      key={s}
                      className="text-xs font-mono px-2.5 py-1 rounded-full bg-white/5 text-[#c3cad4] border border-white/10"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
